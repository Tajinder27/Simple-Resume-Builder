import React from 'react';

function ResumePreview({ data }) {
  return (
    <div className="space-y-4 text-black dark:text-white">
      <h1 className="text-2xl font-bold">{data.name}</h1>
      <p className="text-sm text-gray-600 dark:text-gray-300">{data.email}</p>
      <hr className="border-gray-400" />

      <h2 className="font-semibold">Summary</h2>
      <p className="whitespace-pre-wrap">{data.summary}</p>

      <h2 className="font-semibold">Education</h2>
      <p className="whitespace-pre-wrap">{data.education}</p>

      <h2 className="font-semibold">Experience</h2>
      <p className="whitespace-pre-wrap">{data.experience}</p>

      <h2 className="font-semibold">Skills</h2>
      <p className="whitespace-pre-wrap">{data.skills}</p>
    </div>
  );
}

export default ResumePreview;
