import React from 'react';

function ResumeForm({ data, setData }) {
  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const validateEmail = (email) => {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
};



  return (
    <div className="w-full md:w-1/2 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md text-black dark:text-white">
      <h2 className="text-2xl font-bold text-blue-700 dark:text-blue-300 mb-6 border-b pb-2">Enter Your Details</h2>

      <div className="mb-5">
        <label className="block text-sm font-medium mb-1">Name*</label>
        <input
          type="text"
          name="name"
          value={data.name}
          onChange={handleChange}
          placeholder="Your full name"
          className="w-full border border-gray-300 rounded p-2 focus:ring-2 focus:ring-blue-400"
          required
        />
      </div>

       <div className="mb-5">
  <label className="block text-sm font-medium mb-1">Email*</label>
  <input
    type="email"
    name="email"
    value={data.email}
    onChange={handleChange}
    placeholder="example@email.com"
    className={`w-full border ${
      data.email && !validateEmail(data.email) ? 'border-red-500' : 'border-gray-300'
    } rounded p-2 focus:ring-2 focus:ring-blue-400`}
    required
  />
  {data.email && !validateEmail(data.email) && (
    <p className="text-red-500 text-sm mt-1">Please enter a valid email address.</p>
  )}
</div>



      <div className="mb-5">
        <label className="block text-sm font-medium mb-1">Education</label>
        <textarea
          name="education"
          rows="2"
          value={data.education}
          onChange={handleChange}
          placeholder="Your education details"
          className="w-full border border-gray-300 rounded p-2"
        />
      </div>

      <div className="mb-5">
        <label className="block text-sm font-medium mb-1">Experience</label>
        <textarea
          name="experience"
          rows="3"
          value={data.experience}
          onChange={handleChange}
          placeholder="Your work or project experience"
          className="w-full border border-gray-300 rounded p-2"
        />
      </div>

      <div className="mb-5">
        <label className="block text-sm font-medium mb-1">Skills</label>
        <textarea
          name="skills"
          rows="2"
          value={data.skills}
          onChange={handleChange}
          placeholder="Your technical skills"
          className="w-full border border-gray-300 rounded p-2"
        />
      </div>

      <div className="mb-5">
        <label className="block text-sm font-medium mb-1">Summary</label>
        <textarea
          name="summary"
          rows="3"
          value={data.summary}
          onChange={handleChange}
          placeholder="Short professional summary"
          className="w-full border border-gray-300 rounded p-2"
        />
      </div>
    </div>
  );
}

export default ResumeForm;
