import React, { useRef, useState, useEffect } from 'react';
import { useReactToPrint } from 'react-to-print';
import ResumeForm from './components/ResumeForm';
import ResumePreview from './components/ResumePreview';

function App() {
  const resumeRef = useRef();

  const [resumeData, setResumeData] = useState({
    name: '',
    email: '',
    summary: '',
    education: '',
    experience: '',
    skills: '',
  });

  // Load saved data if present
  useEffect(() => {
    const savedData = localStorage.getItem('resumeData');
    if (savedData) {
      setResumeData(JSON.parse(savedData));
    }
  }, []);

  // Save to local storage on data change
  useEffect(() => {
    localStorage.setItem('resumeData', JSON.stringify(resumeData));
  }, [resumeData]);

  // Print handler
  const handlePrint = useReactToPrint({
    content: () => resumeRef.current,
    documentTitle: 'My_Resume',
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 to-blue-100 p-6 dark:from-gray-800 dark:to-gray-900">
      <h1 className="text-4xl font-bold text-center text-blue-900 dark:text-white mb-8">Smart Resume Builder</h1>

      <div className="flex flex-col md:flex-row gap-6 max-w-5xl mx-auto">
        <ResumeForm data={resumeData} setData={setResumeData} />

        <div ref={resumeRef} className="w-full md:w-1/2 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md">
          <ResumePreview data={resumeData} />
        </div>
      </div>

      <div className="text-center mt-6">
        <button
          onClick={handlePrint}
          className="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-2 rounded shadow"
        >
          Download PDF
        </button>
      </div>
    </div>
  );
}

export default App;
